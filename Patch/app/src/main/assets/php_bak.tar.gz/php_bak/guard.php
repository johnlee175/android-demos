<?php

$post_json = file_get_contents("php://input");
$post_obj = json_decode($post_json);
if (is_null($post_obj)
    || !property_exists($post_obj, "date")
    || !property_exists($post_obj, "code")
    || !property_exists($post_obj, "flavor")
    || !property_exists($post_obj, "src_stack")) {
    die("Got invalid parameters!");
}

$tmp = tempnam(sys_get_temp_dir(), "stacktrace_");
$handle = fopen($tmp, "w+");
fwrite($handle, $post_obj->src_stack);
fflush($handle);

$date = $post_obj->date;
$code = $post_obj->code;
$flavor = $post_obj->flavor;

#chdir("/usr/local/var/www/files/mapping");
chdir("/usr/share/nginx/html/mapping");
$dir = glob("*".$date."*".$code, GLOB_ONLYDIR);
$dirSize = sizeof($dir);
if ($dirSize <= 0) {
    die("No one matched!");
} else if ($dirSize > 1) {
    die("More one matched!");
}

$mappingFile = getcwd()."/".$dir[0]."/".$flavor."/release/mapping.txt";
if (!file_exists($mappingFile)) {
    die("Target mapping file not exist!");
}
if (!file_exists($tmp)) {
    die("Target stacktrace file not exist!");
}

$androidHome="/home/users/bdserver/android-sdk-linux";
#$androidHome = getenv('ANDROID_HOME');
if (strlen(trim($androidHome)) == 0) {
    die('Please check the $ANDROID_HOME variable!');
}

$cmd = $androidHome."/tools/proguard/bin/retrace.sh ".$mappingFile." ".$tmp." 2>&1";
$result = shell_exec($cmd);
echo htmlspecialchars($result);

?>
