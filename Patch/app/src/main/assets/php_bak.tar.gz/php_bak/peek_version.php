<?php
include 'common.php';

$post_obj = get_post_json();

log_obj($post_obj);

if (!check_properties($post_obj, ['product', 'flavor', 'device'
    'device_version', 'branch', 'apk_md5', 'mapping_code', 'build_date',
    'up_to_date', 'forward_step', 'prepare_patch'])) {
    die_with(-1, 'Got invalid parameters!');
}

$product = $post_obj->product;
$flavor = $post_obj->flavor;
$branch = $post_obj->branch;
$apk_md5 = $post_obj->apk_md5;
$mapping_code = $post_obj->mapping_code;
$build_date = $post_obj->build_date;
$up_to_date = $post_obj->up_to_date;
$forward_step = $post_obj->forward_step;
$prepare_patch = $post_obj->prepare_patch;
$device = $post_obj->device;
$device_version = $post_obj->device_version;

//TODO here filter which device and/or device version to apply update service

chdir("${web_root}/apk");
$dir = glob("${product}-${branch}_${build_date}*_${mapping_code}", GLOB_ONLYDIR);
$dir_size = sizeof($dir);
if ($dir_size <= 0) {
    die_with(-1, 'No version matched!');
} else if ($dir_size > 1) {
    die_with(-1, 'More one version matched!');
}

$mapping_dir = $dir[0];
$mapping_path = "${mapping_dir}/app-${flavor}-release_".substr($apk_md5, -7).".apk";
$mapping_apk = getcwd().'/'.$mapping_path;
if (!file_exists($mapping_apk)) {
    die_with(-1, 'Mapping apk not exist!');
}
$mapping_md5 = md5_file($mapping_apk);
if ($mapping_md5 != $apk_md5) {
    die_with(-1, 'MD5 is invalid!');
}

$dirs = glob("${product}-${branch}_*", GLOB_ONLYDIR);
rsort($dirs);

$target_dir = '';
if ($up_to_date) {
    $target_dir = $dirs[0];
} else {
    $dir_size = sizeof($dirs);
    for ($i = 0; $i < $dir_size; ++$i) {
        if ($dirs[$i] == $mapping_dir) {
            if ($forward_step) {
                if ($i == 0) {
                    $target_dir = $dirs[$i];
                } else {
                    $target_dir = $dirs[$i - 1];
                }
            } else {
                if ($i == ($dir_size - 1)) {
                    $target_dir = $dirs[$i];
                } else {
                    $target_dir = $dirs[$i + 1];
                }
            }
            break;
        }
    }
}

$target_path = "";
if (is_dir($target_dir)) {
    if ($path = opendir($target_dir)) {
        while ($file = readdir($path)) {
            if (strpos($file, "-${flavor}-") > 0) {
                $target_path = "${target_dir}/${file}";
                break;
            }
        }
    }   
}
$target_apk = getcwd().'/'.$target_path;
$target_md5 = md5_file($target_apk);

$from = array('path'=>substr($mapping_path, 0, -4), 'md5'=>$mapping_md5);
$to = array('path'=>substr($target_path, 0, -4), 'md5'=>$target_md5);

$patch_size = '';
if ($prepare_patch && $mapping_path != $target_path) {
    $patch_file = "${mapping_dir}_${target_dir}.patch";
    if ($up_to_date) {
        chdir("${web_root}/patches");
        $fp = fopen('gen.lock', 'r+');
        if ($fp) {
            if (flock($fp, LOCK_EX | LOCK_NB)) {
                if (file_exists($patch_file)) {
                    $patch_size = strval(filesize($patch_file));
                }
                flock($fp, LOCK_UN);
            } /* else the generator is working */
            fclose($fp);
        }
    }
    if ($patch_size == '') {
        chdir("${web_root}/tmp_patches");
        $fp = fopen('cls.lock', 'r+');
        if ($fp) {
            while (!flock($fp, LOCK_EX)) {
               sleep(1); // cleaning, wait 
            }
            flock($fp, LOCK_UN);
            fclose($fp);
        }
        if (file_exists($patch_file)) { // patch file exists after cleaning
            $patch_size = strval(filesize($patch_file));
        } else {
            shell_exec("bsdiff ${mapping_apk} ${target_apk} ${patch_file}");
            $patch_size = strval(filesize($patch_file));
        }
    }
}

$resp_json = array('code'=>'0', 'message'=>'ok', 'current'=>$from, 'target'=>$to, 'patch_size'=>$patch_size);
echo json_encode($resp_json);

?>
