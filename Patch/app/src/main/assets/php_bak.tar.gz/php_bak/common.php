<?php

$web_root = $_SERVER['DOCUMENT_ROOT'];

function get_post_json() {
    $encoding = isset($_SERVER['HTTP_CONTENT_ENCODING']) ? $_SERVER['HTTP_CONTENT_ENCODING'] : '';
    $raw_body = file_get_contents('php://input');
    $has_gzip = stripos($encoding, 'gzip');
    if ($has_gzip < 0 || ($has_gzip == false && $has_gzip != 0)) { // normal
        $post_json = $raw_body;
    } else { // gzip
        $post_json = gzdecode($raw_body);
    }
    return json_decode($post_json);
}

function try_lock($relative_lock_file_path, $success_callback_name, $fail_callback_name) {
    global $web_root;
    $fp = fopen($web_root.'/'.$relative_lock_file_path, 'r');
    if (flock($fp, LOCK_EX | LOCK_NB)) {
        call_user_func($success_callback_name);
        flock($fp, LOCK_UN);
    } else {
        call_user_func($fail_callback_name);
    }
    fclose($fp);
}

function check_properties($obj, $prop_list) {
    if (is_null($obj)) {
        return false;
    }
    foreach($prop_list as $var) {
        if (!property_exists($obj, $var)) {
            return false;
        }
    }
    return true;
}

function die_with($code, $message) {
    die(json_encode(array('code'=>$code, 'message'=>$message)));
}

function die_header_with($code, $message) {
    header('code: '.strval($code));
    header('message: '.strval($message));
    exit(1);
}

function download_it($downloading_file_path, $file_name) {
    $speed = 1024 * 1024; //max download speed is 1MB if possible
	$file_resource = fopen($downloading_file_path, 'r');
	$file_size = filesize($downloading_file_path);
	if (isset($_SERVER['HTTP_RANGE']) && !empty($_SERVER['HTTP_RANGE'])) { 
		$range = $_SERVER['HTTP_RANGE']; 
		$range = preg_replace('/[\s|,].*/', '', $range); 
		$range = explode('-', substr($range, 6)); 
		if (count($range) < 2) { 
			$range[1] = $file_size; 
		} 
		$range = array_combine(array('start','end'), $range); 
		if (empty($range['start'])) { 
			$range['start'] = 0; 
		} 
		if (empty($range['end'])) { 
			$range['end'] = $file_size; 
		} 
	      	header('HTTP/1.1 206 Partial Content');
	      	header('Content-Length: '.strval($range['end'] - $range['start']));
	      	header('Content-Range: bytes '.$range['start'].'-'.$range['end'].'/'.$file_size);
	      	fseek($file_resource, $ranges['start']);
	} else {
		header('HTTP/1.1 200 OK');
 	    header('Content-Length: '.$file_size);
	} 
	header('Connection: Keep-Alive');
	header('Content-Type: application/octet-stream');
	header('Accept-Ranges: bytes');
 	header("Content-Disposition: attachment; filename=${file_name}");
	while(!feof($file_resource)) {
		set_time_limit(0);
		echo fread($file_resource, round($speed));
		ob_flush();
		flush();
	}
	fclose($file_resource);
}

function log_obj($obj, $pr = false) {
    if ($pr) {
        log_str(print_r($obj, true)."\n");
    } else {
        ob_start();
        var_dump($obj);
        log_str(ob_get_clean());
    }
}

function log_str($str) {
    $log_dir = './logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir);
    }
    $fp = fopen($log_dir.'/log_'.date('Y-m-d').'.txt', 'a+');
    fwrite($fp, date('Y-m-d H:i:s')."\t".$str);
    fclose($fp);
}

?>
