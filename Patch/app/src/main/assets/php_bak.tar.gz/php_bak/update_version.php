<?php
include 'common.php';

$post_obj = get_post_json();
if (!check_properties($post_obj, ['from', 'to'])) {
    die_header_with(-1, 'Got invalid parameters!');
}
$from = $post_obj->from;
$to = $post_obj->to;
if (!check_properties($from, ['path', 'md5']) 
    || !check_properties($to, ['path', 'md5'])) {
    die_header_with(-1, 'Got invalid parameters!');
}
$from_path = $from->path.'.apk';
$from_md5 = $from->md5;
$to_path = $to->path.'.apk';
$to_md5 = $to->md5;
if ($from_path == $to_path || $from_md5 == $to_md5) {
    die_header_with(-1, 'Got invalid parameters!');
}

chdir("${web_root}/apk");
if (file_exists($from_path) && file_exists($to_path)) {
    $calc_from_md5 = md5_file($from_path);
    $calc_to_md5 = md5_file($to_path);
    if ($calc_from_md5 != $from_md5) {
        die_header_with(-1, "From md5 not matched, file may be changed!");
    }
    if ($calc_to_md5 != $to_md5) {
        die_header_with(-1, "To md5 not matched, file may be changed!");
    }
    $mapping_apk = getcwd().'/'.$from_path;
    $target_apk = getcwd().'/'.$to_path;
    $mapping_dir = explode('/', $from_path)[0];
    $target_dir = explode('/', $to_path)[0];
    $patch_file = "${mapping_dir}_${target_dir}.patch";
    $download_file = '';
    chdir("${web_root}/patches");
    $fp = fopen('gen.lock', 'r+');
    if ($fp) {
        if (flock($fp, LOCK_EX | LOCK_NB)) {
            if (file_exists($patch_file)) {
                $download_file = getcwd().'/'.$patch_file;
            }
            flock($fp, LOCK_UN);
        } /* else the generator is working */
        fclose($fp);
    }
    if (!$download_file) {
        chdir("${web_root}/tmp_patches");
        $fp = fopen('cls.lock', 'r+');
        if ($fp) {
            while (!flock($fp, LOCK_EX)) {
                sleep(1); // cleaning, wait
            }
            flock($fp, LOCK_UN);
            fclose($fp);
        }
        if (file_exists($patch_file)) { // patch file exists after cleaning
            $download_file = getcwd().'/'.$patch_file;
        } else {
            shell_exec("bsdiff ${mapping_apk} ${target_apk} ${patch_file}");
            $download_file = getcwd().'/'.$patch_file;
        }
    }
    if (!$download_file) {
        die_header_with(-1, 'Patch file create or reference failed!');
    }
    $patch_md5 = md5_file($download_file);
    header('code: 0');
    header('message: ok');
    header("target-md5: ${to_md5}");
    header("patch-md5: ${patch_md5}");
    download_it($download_file, $patch_file);
} else {
    die_header_with(-1, "Path from: ${from_path} or to: ${to_path} is invalid!");
}

?>
