#!/bin/bash
DIR=$1
MINITES=$2
flock -x "$DIR/cls.lock" -c "find $DIR -type f \( ! -name '*.lock' \) -mmin +$MINITES -exec rm -rf {} \; "

# how to know cron tasks had executed, just shell it:
# sudo tail -f /var/log/cron
# or shell it:
# sudo vim /var/spool/mail/[username]
