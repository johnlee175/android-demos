#!/usr/bin/env python


import os
import sys
import datetime
import random
import shutil
import hashlib
import re


def md5sum(file_name):
    def read_chunks(file_pointer):
        file_pointer.seek(0)
        chunk_data = file_pointer.read(8096)
        while chunk_data:
            yield chunk_data
            chunk_data = file_pointer.read(8096)
        else:
            file_pointer.seek(0)
    m = hashlib.md5()
    if isinstance(file_name, basestring) and os.path.exists(file_name):
        with open(file_name, "rb") as fh:
            for chunk in read_chunks(fh):
                m.update(chunk)
    elif file_name.__class__.__name__ in ["StringIO", "StringO"] or isinstance(file_name, file):
        for chunk in read_chunks(file_name):
            m.update(chunk)
    else:
        return ""
    return m.hexdigest()


def main(argv):
    if len(argv) < 3:
        print 'WARNING: More option parameters needed!'
        return
    if not os.path.exists(argv[1]) or not os.path.isdir(argv[1]):
        print 'WARNING: The target file not exists or is not directory!'
        return
    if len(str(argv[2]).strip()) <= 0:
        print 'WARNING: The target application name missing!'
        return
    pub_apk_path = '/usr/share/nginx/html/apk/'
    pub_map_path = '/usr/share/nginx/html/mapping/'
    # pub_apk_path = '/usr/local/var/www/files/apk'
    # pub_map_path = '/usr/local/var/www/files/mapping'
    if not os.path.exists(pub_apk_path):
        os.mkdir(pub_apk_path)
    if not os.path.exists(pub_map_path):
        os.mkdir(pub_map_path)
    apk_dir = argv[1] + '/build/outputs/apk/'
    map_dir = argv[1] + '/build/outputs/mapping/'

    seed = '0'
    seed_path = os.path.join(os.path.dirname(argv[1]), '.seed')
    if os.path.exists(seed_path):
        seed = open(seed_path).read()
    key = argv[2] + '_' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S') + '_' + str(random.randint(0, 999)) + '_' + seed

    res_map_pattern = re.compile(r'resource_mapping_(\w+)-(\w+)-(\w+).txt')

    if not os.path.exists(map_dir):
        return
    map_new_dir = os.path.join(pub_map_path, key)
    if os.path.exists(map_new_dir):
        shutil.rmtree(map_new_dir)
    shutil.copytree(map_dir, map_new_dir, ignore=shutil.ignore_patterns('dump.txt'))

    if not os.path.exists(apk_dir):
        return
    apk_new_dir = os.path.join(pub_apk_path, key)
    if os.path.exists(apk_new_dir):
        shutil.rmtree(apk_new_dir)
    os.mkdir(apk_new_dir)
    for parent, dir_names, file_names in os.walk(apk_dir):
        if not os.path.split(parent)[1].startswith('AndResGuard'):
            continue
        for file_name in file_names:
            old_file = os.path.join(parent, file_name)
            if res_map_pattern.match(file_name):
                product_flavor = res_map_pattern.match(file_name).group(2)
                build_type = res_map_pattern.match(file_name).group(3)
                target = os.path.join(map_new_dir, product_flavor, build_type)
                if os.path.exists(target):
                    shutil.copyfile(old_file, os.path.join(target, file_name[:16] + '.txt'))
                continue
            if file_name.find('_signed_aligned.apk') < 0:
                continue
            new_name = file_name[:-19] + '_' + md5sum(old_file)[-7:] + '.apk'
            shutil.copyfile(old_file, os.path.join(apk_new_dir, new_name))
    if argv[2].split('-')[1] == 'master':
        os.system('python ' + os.path.dirname(__file__)  + '/patch_newest.py -c phone -n ' + key)

if __name__ == '__main__':
    main(sys.argv)

