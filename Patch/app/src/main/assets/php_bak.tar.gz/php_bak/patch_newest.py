#!/usr/bin/env python


import os
import sys
import multiprocessing
import re
import fcntl
import time

base_path = '/usr/share/nginx/html/apk'
output_path = '/usr/share/nginx/html/patches'


def proc(command, out_path):
    print command
    os.chdir(out_path)
    os.popen(command)


def lock(fstr):
    fp = open(fstr, "r")
    fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
    return fp


def unlock(fp):
    if fp is not None:
        fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
        fp.close()


def desc_dir(parent_dir, custom_prefix):
    dirs = []
    for f in os.listdir(parent_dir):
        fp = os.path.join(parent_dir, f)
        if os.path.isdir(fp) and f.startswith(custom_prefix):
            dirs.append(fp)
    dirs.sort(reverse=True)
    return dirs


def search_file(parent_dir, custom_prefix):
    for f in os.listdir(parent_dir):
        fp = os.path.join(parent_dir, f)
        if os.path.isfile(fp) and f.startswith(custom_prefix):
            return fp
    return ''


def parse_opt(argv):
    import optparse
    usage = 'Usage: %prog [[options] [value]]'
    desc = 'Example: %prog -c phone -n robokit-dev_20161124-170320_473_7908173'
    parser = optparse.OptionParser(usage=usage, description=desc)
    parser.add_option('-c', dest='channel', type='string', help="special the product flavor",
                      default='phone', metavar='PRODUCT_FLAVOR')
    parser.add_option('-n', dest='newest', type='string', help='special the newest archive',
                      default=' ', metavar='NEWEST_ARCHIVE')
    options, categories = parser.parse_args(argv[1:])
    return options.channel, options.newest


def main(argv):
    pattern = re.compile(r'^([a-zA-Z0-9]+)-([a-zA-Z0-9]+)_(\d+)-(\d+)_(\d+)_(\d+)$')
    channel, newest = parse_opt(argv)
    if not channel or len(channel.strip()) == 0:
        print 'The valid product flavor is required, please with -c {PRODUCT_FLAVOR}'
        return
    if not newest or len(newest.strip()) == 0 or not pattern.match(newest):
        print 'The valid newest archive is required, please with -n {NEWEST_ARCHIVE}'
        return
    product = pattern.match(newest).group(1)
    branch = pattern.match(newest).group(2)
    apk_pattern = 'app-' + channel + '-release_'
    target_apk = search_file(os.path.join(base_path, newest), apk_pattern)
    dirs = desc_dir(base_path, product + '-' + branch)
    fp = lock(os.path.join(output_path, 'gen.lock'))
    try:
        start_time = int(time.time())
        for parent, dir_names, file_names in os.walk(output_path):
            for file_name in file_names:
                path = os.path.join(parent, file_name)
                if os.path.isfile(path) and file_name.endswith('.patch'):
                    os.remove(path)
        pool = multiprocessing.Pool(processes=6)
        is_start_search = False
        for d in dirs:
            olderone = os.path.basename(d)
            if olderone == newest:
                is_start_search = True
                continue
            if is_start_search:
                source_apk = search_file(d, apk_pattern)
                command = 'bsdiff ' + source_apk + ' ' + target_apk + ' ' + olderone + '_' + newest + '.patch'
                pool.apply_async(proc, (command, output_path))
        pool.close()
        pool.join()
        end_time = int(time.time())
        print 'All patches generate done with ' + str(end_time - start_time) + 's !'
    finally:
        unlock(fp)


if __name__ == '__main__':
    main(sys.argv)
