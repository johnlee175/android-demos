<!DOCTYPE html><html><head><title>FPA</title><meta charset='utf-8'><link href='https://dn-maxiang.qbox.me/res-min/themes/marxico.css' rel='stylesheet'><style></style></head><body><div id='preview-contents' class='note-content'>
                        <div id="wmd-preview" class="preview-content"></div>
                    <div class="wmd-preview-section preview-content" id="wmd-preview-section-9"></div><div class="wmd-preview-section preview-content" id="wmd-preview-section-11">

<h4 id="朋友-你想安装所有的durobot出品的最新app到你指定的手机或机器人上吗">朋友, 你想安装所有的duRobot出品的最新app到你指定的手机或机器人上吗?</h4>

</div><div class="wmd-preview-section preview-content" id="wmd-preview-section-36">

<h4 id="你是其中某个app的开发者-你的app依赖其他app-或者你想做daily-test-or-nightly-build-看看你的更改是否会对其他app造成影响">你是其中某个app的开发者, 你的app依赖其他app, 或者你想做daily test or nightly build, 看看你的更改是否会对其他app造成影响?</h4></div><div class="wmd-preview-section preview-content" id="wmd-preview-section-13">

<h4 id="你是否正为无法一键自动完成这些工作而发愁呢">你是否正为无法一键自动完成这些工作而发愁呢?</h4>

</div><div class="wmd-preview-section preview-content" id="wmd-preview-section-14">

<h4 id="好消息是-你不需要懂任何技术-现在这些已经很傻瓜了-你只需要">好消息是, 你不需要懂任何技术, 现在这些已经很傻瓜了, 你只需要:</h4>

<ul><li>一个已经开启调试模式的android设备, 对, 就是那样, 你做的很好</li>
<li>保证手机用usb线连接到了pc电脑上, 让我们继续</li>
<li>一个python环境, 我是windows用户, 没有安装python怎么办? 没关系, 请点击<a target="_blank" href="download.php?public=python-windows.zip">这里</a>下载 </li>
</ul>

<hr>

</div><div class="wmd-preview-section preview-content" id="wmd-preview-section-887">

<h4 id="准备好了吗-lets-go">准备好了吗? Let’s GO!</h4>

<p>下载对应你的平台的工具吧, 它们将是你最忠实的工人, 不用付1毛钱, 除非你想打赏给我, 那就联系我吧, 孩子.</p>

<table>
<thead>
<tr>
  <th align="left">平台</th>
  <th align="right">工具</th>
</tr>
</thead>
<tbody><tr>
  <td align="left">Windows</td>
  <td align="right"><a target="_blank" href="download.php?public=fpa-windows.zip">下载</a></td>
</tr>
<tr>
  <td align="left">Linux</td>
  <td align="right"><a target="_blank" href="download.php?public=fpa-linux.zip">下载</a></td>
</tr>
<tr>
  <td align="left">Mac OS X</td>
  <td align="right"><a target="_blank" href="download.php?public=fpa-macosx.zip">下载</a></td>
</tr>
</tbody></table>


<hr></div><div class="wmd-preview-section preview-content" id="wmd-preview-section-304">

<h4 id="你想问怎么使用-别着急-下面有">你想问怎么使用, 别着急, 下面有:</h4>

<p>你一定知道下载的东西是个压缩包, 是的, 就是它, 快把它解压下; <br>
一般来说, 如果你能打开终端, 那么可以进入那个目录并执行<code>python ./fetch_push_apk.py</code>, 然后世界就太平了, so easy, 不是吗? <br>
<br>
如果你不会使用终端或者你不知道终端是个神马东东, 不要抓狂, 不要尖叫, 往下看:</p>

<ul><li><strong>Windows:</strong> 进入那个目录, 新建一个脚本, 命名为fetch_push_apk.bat, 用记事本打开并粘贴下面代码保存, 即可双击fetch_push_apk.bat运行啦, 前提是你已经将python配置到了环境变量里, 如果没有, 请看如何<a target="_blank" href="http://jingyan.baidu.com/article/bea41d436879a4b4c51be6f9.html">操作</a>  </li>
</ul></div><div class="wmd-preview-section preview-content" id="wmd-preview-section-841">

<pre class="prettyprint hljs-dark"><code class="hljs vim"><span class="hljs-comment line-number">1.</span><span class="hljs-keyword">python</span> ./fetch_push_apk.<span class="hljs-keyword">py</span><br></code></pre>

<p><br></p>

<ul><li><strong>Linux:</strong> 目前在Ubuntu14上做过测试, 如果你也在用它, 我想说你还是乖乖用Terminal吧, 你用它是因为你是个出色的工程师, 我为你感到骄傲, Terminal是最好的方式且是必须掌握的, 不是吗? 当然你也可以百度搜索怎么双击打开, 祝福你. <br>
<br></li>
<li><strong>Mac OS X:</strong> 你想双击就能运行而不打开终端, 那就从Finder进入那个目录, 找到fetch_push_apk.py并重命名为fetch_push_apk.command, OK, 现在双击fetch_push_apk.command.   </li>
</ul>

<hr>

<p>更详细的介绍: <br>
<strong>流程</strong> 目前这个工具会自动最新版下载[‘duRobot-launcher’, ‘duRobot-camera’, ‘duRobot-music’, ‘duRobot-pet’, ‘duRobot-weather’, ‘duRobot-anychat’]这些个app, 默认将他们存在当前目录下的apks目录中, 然后卸载手机上的相同app, 并安装上这些最新的app, 然后如果可能, 杀掉已经启动的相关app进程, 保证不会有任何干扰已经安装顺序的正确, 接下来你可以点击duRobot-launcher这个入口app啦 <br>
<br>
<strong>配置</strong> 你可以使用<code>python ./fetch_push_apk.py --help</code>查看帮助信息, 目前版本有三个可配置项:</p>

<ul><li>下载的app安装包的存放路径可配置, 使用-d选项(directory)加上路径名</li>
<li>如果你的pc上连接了多个android设备, 使用-s选项(special)加上设备ID可以指定安装的设备</li>
<li>使用-c选项(clean)能够在下载安装完所有app后删掉下载的任何安装包</li>
</ul>

<p><br>
<strong>修改</strong> 如果你不想下载安装所有的包, 请打开那个神奇的脚本fetch_push_apk.py, 看到'urls ='这行了吗, 这里声明了item列表, 删掉不需要的item, 保存即可</p>

<hr>

<h4>版本更新</h4>

<strong>2.0</strong>
<ul>
<li>增加了对机器人default.mes的拷入, 可以使用-o选项来执行;</li>
<li>增加了自动更新, 妈妈再也不用为到此网址上下载, 解压, 替换发愁啦! 可以使用-v选项查看当前版本;</li>
</ul>

<hr>

<p>如有其它问题或建议可以联系开发者, 邮箱lizhehao@baidu.com, 多谢支持!!!</p></div><div class="preview-content" id="wmd-preview-section-footnotes"></div></div></body></html>
