<?php

$uploadDir = "upload"; // should using readonly directory
if ($_FILES["file"]["error"] > 0) {
	die("Error: Code is ".$_FILES["file"]["error"]."!<br/>");
} else {
	$fileType = $_FILES["file"]["type"];
	if (strpos($fileType, "python") || strpos($fileType, "perl") || strpos($fileType, "php") || $fileType == "application/x-sh"
		|| $_FILES["file"]["size"] > 200 * 1024 * 1024 ) {
		die("Error: The uploading file's type or size is not supported!<br/>");
	} else {
		$fileTmpName = $_FILES["file"]["tmp_name"];
		if (!is_uploaded_file($fileTmpName)) {
			die("Error: The tmp file is not valid upload file!<br/>");
		}
		$fileName = $_FILES["file"]["name"];
		if (strpos($fileName, "/")) {
                        $fileName = substr($fileName, strrpos($fileName, "/"));
                }
		$fileEncodedName = urlencode($fileName);
		$filePath = $uploadDir."/".$fileEncodedName;
		if (file_exists($filePath)) {
			echo "Warning: ".$fileName." already exists, will be overwritten.<br/>";
		}
		if (move_uploaded_file($_FILES["file"]["tmp_name"], $filePath)) {
			if (chmod($filePath, 0444)) {
				echo $fileName." uploaded successfully!<br/>".
		     	     	     "You can download it from the website's root path with request uri: /download.php?public=".$fileEncodedName."<br/>";
			} else {
				die("Error: Insecure file permissions!<br/>");
			}
		} else {
			die("Error: Move uploaded file to correct position failed!<br/>");
		}	
	}
}

?>
