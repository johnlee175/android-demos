<?php

$speed = 1024 * 1024; //max download speed is 1MB if possible
$public_file = $_GET['public'];
if (strpos($public_file, '/')) {
	$public_file = substr($public_file, strrpos($public_file, '/'));
}
$uploadDir = 'upload';
$downloading_file_path = $uploadDir.'/'.$public_file;
if (!file_exists($downloading_file_path)) {
	die('Error: Requesting file is not found!');
} else {
	$file_resource = fopen($downloading_file_path, 'r');
	$file_size = filesize($downloading_file_path);
	if (isset($_SERVER['HTTP_RANGE']) && !empty($_SERVER['HTTP_RANGE'])) { 
		$range = $_SERVER['HTTP_RANGE']; 
		$range = preg_replace('/[\s|,].*/', '', $range); 
		$range = explode('-', substr($range, 6)); 
		if (count($range) < 2) { 
			$range[1] = $file_size; 
		} 
		$range = array_combine(array('start','end'), $range); 
		if (empty($range['start'])) { 
			$range['start'] = 0; 
		} 
		if (empty($range['end'])) { 
			$range['end'] = $file_size; 
		} 
	      	header('HTTP/1.1 206 Partial Content');
	      	header('Content-Length: '.strval($range['end'] - $range['start']));
	      	header('Content-Range: bytes '.$range['start'].'-'.$range['end'].'/'.$file_size);
	      	fseek($file_resource, $ranges['start']);
	} else {
		header('HTTP/1.1 200 OK');
 	      	header('Content-Length: '.$file_size);
	} 
	header('Connection: Keep-Alive');
	header('Content-Type: application/octet-stream');
	header('Accept-Ranges: bytes');
 	header('Content-Disposition: attachment; filename='.$public_file);
	while(!feof($file_resource)) {
		set_time_limit(0);
		echo fread($file_resource, round($speed));
		ob_flush();
		flush();
	}
	fclose($file_resource);
	exit();
}

?>
